CPE453-Lab6
Names:
Parth Ray
Gaurav Joshi

To Compile:
    make allocator

To Run:
    ./allocator [size]

What we each did:
Parth Ray: Did whole thing together
Gaurav Joshi: Did whole thing together
